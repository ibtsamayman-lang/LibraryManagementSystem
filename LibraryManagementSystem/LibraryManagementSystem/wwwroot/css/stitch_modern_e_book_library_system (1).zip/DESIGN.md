---
name: Athenaeum
colors:
  surface: '#faf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#faf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#e9e8e5'
  surface-container-highest: '#e3e2df'
  on-surface: '#1a1c1a'
  on-surface-variant: '#43474c'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f2f1ee'
  outline: '#74777d'
  outline-variant: '#c4c6cd'
  surface-tint: '#4e6073'
  primary: '#162839'
  on-primary: '#ffffff'
  primary-container: '#2c3e50'
  on-primary-container: '#96a9be'
  inverse-primary: '#b5c8df'
  secondary: '#795900'
  on-secondary: '#ffffff'
  secondary-container: '#ffc641'
  on-secondary-container: '#715300'
  tertiary: '#1d292a'
  on-tertiary: '#ffffff'
  tertiary-container: '#333f40'
  on-tertiary-container: '#9daaab'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4fb'
  primary-fixed-dim: '#b5c8df'
  on-primary-fixed: '#091d2e'
  on-primary-fixed-variant: '#36485b'
  secondary-fixed: '#ffdfa0'
  secondary-fixed-dim: '#f6be39'
  on-secondary-fixed: '#261a00'
  on-secondary-fixed-variant: '#5c4300'
  tertiary-fixed: '#d8e5e6'
  tertiary-fixed-dim: '#bcc9ca'
  on-tertiary-fixed: '#121e1f'
  on-tertiary-fixed-variant: '#3d494a'
  background: '#faf9f6'
  on-background: '#1a1c1a'
  surface-variant: '#e3e2df'
typography:
  headline-xl:
    fontFamily: Literata
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Literata
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Literata
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Literata
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style
The design system is centered on a "Modern Library" aesthetic—blending the prestige of traditional academia with the streamlined efficiency of a digital e-book platform. The brand personality is authoritative yet welcoming, intellectual, and highly organized. 

The design style leverages **Minimalism** with a **Tactile** touch. It avoids unnecessary ornamentation, focusing instead on spatial clarity, intentional typography, and subtle physical metaphors (like the weight of a book cover) to evoke a sense of quality and permanence. The goal is to provide a focused reading and browsing environment that minimizes cognitive load while maintaining a sophisticated, literary atmosphere.

## Colors
The palette is grounded in a deep, scholarly Navy (#2c3e50) used for core structural elements, primary branding, and high-level navigation. This is contrasted by a Warm Gold (#d4a017) accent, used sparingly for calls-to-action, highlights, and "premium" states to evoke gold-leaf embossing.

The background uses a soft Off-white (#f8f7f4), which reduces eye strain compared to pure white and mimics the texture of high-quality cream paper. Functional grays are utilized for secondary text and borders to maintain a low-contrast, calm environment.

## Typography
This design system employs a pairing of **Literata** and **Hanken Grotesk**. 

**Literata** is used for all headlines and serif accents. Its design, originally intended for long-form digital reading, provides an authoritative and literary feel that anchors the page. 

**Hanken Grotesk** is used for body copy, UI labels, and data. Its clean, contemporary grotesque letterforms provide a necessary functional contrast to the serif headings, ensuring that metadata and interface elements remain highly legible and professional. 

For mobile devices, `headline-xl` should scale down to `32px` to ensure readability and prevent awkward text wrapping.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy for desktop, centering the content within a 1280px container to maintain the focused feel of a book. On mobile and tablet, the layout transitions to a **Fluid Grid** with consistent 24px side margins.

A modular 8px scale drives all spacing decisions. Content is organized into clear vertical rhythm blocks. Large-scale sections are separated by `lg` (48px) or `xl` (80px) spacing to emphasize the minimalist, airy aesthetic.

**Breakpoints:**
- Mobile: < 600px (4 columns, 16px gutter)
- Tablet: 600px - 1024px (8 columns, 24px gutter)
- Desktop: > 1024px (12 columns, 24px gutter)

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows**. 

The base layer is the Off-white background. Cards and primary containers sit on a "Level 1" elevation, using a white background with an extremely soft, diffused shadow (12px blur, 4% opacity, tinted with the primary navy color). 

Hover states on interactive cards should increase the elevation to "Level 2," intensifying the shadow slightly and applying a subtle 2px upward translation to simulate a physical lift. Navigation bars should use a "Level 1" shadow or a simple 1px border (#e0ddd5) to maintain a flat, scholarly profile.

## Shapes
The shape language is defined by a "Rounded" (0.5rem / 8px) corner radius. This softens the formal nature of the typography and color palette, making the digital library feel modern and approachable. 

Larger containers like modal windows or hero book cards should utilize `rounded-lg` (1rem / 16px) to emphasize their role as primary content vessels. Small components like tags or checkboxes should maintain the base 8px radius to ensure a cohesive visual vocabulary.

## Components

**Navigation Bar**
A clean, horizontal bar at the top with a fixed height. Use a white background with a subtle bottom border (#e0ddd5). The logo sits on the far left, while profile and library icons are grouped on the right. Links should use `label-md` for a precise, professional look.

**Book Cards**
The centerpiece of the UI. Use a vertical aspect ratio for the book cover. Title (`headline-sm`) and Author (`body-sm`) are placed below the image. On hover, the card lifts (see Elevation) and a Warm Gold (#d4a017) accent line appears at the bottom of the card.

**Filter Sidebars**
Structured with clear `label-md` headings in the primary navy color. Use thin horizontal dividers to separate filter categories (Genre, Year, Availability). Checkboxes should be 18px squares with 4px rounded corners.

**Input Fields & Forms**
Fields use a white background with a 1px border (#d1cfc8). When focused, the border shifts to the primary navy blue with a subtle 2px outer glow in a semi-transparent navy. Labels sit above the field using `label-sm`.

**Buttons**
- **Primary:** Solid Navy (#2c3e50) with White text.
- **Secondary:** Transparent background with Navy border and text.
- **Accent:** Warm Gold (#d4a017) with Navy text (used only for "Read Now" or "Purchase" actions).
All buttons have 8px rounded corners and use `label-md` typography.

**Chips/Tags**
Used for genres or statuses (e.g., "Available"). Use a light tint of the primary color with 16px (fully rounded) corners for a pill-shaped appearance, ensuring they look distinct from actionable buttons.